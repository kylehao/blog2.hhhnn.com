(function($){
  $(function(){
    $(".button-collapse").sideNav();
  });
})(jQuery);