---
title: 世界之窗
youtube_id: 22142794
cover_id: img/videos_cover/105.jpg
date: 2018-04-15
tags: [世界之窗, vlog, 深圳,wblearn]
---
我不想遗漏那些美好,也不想遗漏那些不足。

视频首发[我的微博](http://weibo.com/wudalanggd)，欢迎关注。视频原地址戳下面：

* [ 世界之窗](https://www.bilibili.com/video/av22142794)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**
