---
title: 深圳中心公园
youtube_id: 21730913
cover_id: img/videos_cover/b4b071602d5549bbfaa4eb105fd88453915c62ff.jpg
date: 2018-01-13
tags: [公园, vlog, 深圳,wblearn]
---
记录日常生活的vlog。。。

逛公园~

视频原地址戳下面：

* [深圳中心公园](https://www.bilibili.com/video/av21730913)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**
