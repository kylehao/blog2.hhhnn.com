---
title: 莲花山公园
youtube_id: 21730861
cover_id: img/videos_cover/88c56642ff5464a353d4863ce679924f2c0a1ce8.jpg
date: 2018-03-16
tags: [公园, vlog, 深圳,wblearn]
---
记录日常生活的vlog。。。

逛公园~

视频首发[我的微博](http://weibo.com/wudalanggd)，欢迎关注。视频原地址戳下面：

* [莲花山公园](https://www.bilibili.com/video/av21730861)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**
