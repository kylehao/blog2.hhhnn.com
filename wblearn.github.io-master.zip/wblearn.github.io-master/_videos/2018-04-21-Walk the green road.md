---
title: 漫步绿道
youtube_id: 22454127
cover_id: img/videos_cover/68de84cfb2eb51cb13062033e38c2e5e46e5170a.jpg
date: 2018-04-21
tags: [绿道, vlog, 深圳,wblearn,日常]
---
记录日常生活的vlog。。。

逛公园~

视频首发[我的微博](http://weibo.com/wudalanggd)，欢迎关注。视频原地址戳下面：

* [ 漫步绿道](https://www.bilibili.com/video/av22454127)

**PS:	之前此video页面是我自己为我的博客定制的一个videos页面(视频集成于youtube，国内的需翻墙才能看)，主要是youtube没广告，
后来实在受不了每次上传视频到youtube时我那VPN的龟速，于是选择了国内二次元视频网站bilibili：)**