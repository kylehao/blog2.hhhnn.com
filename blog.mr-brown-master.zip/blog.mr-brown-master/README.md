#Mr.Brown is a responsive Jekyll theme
=========================

![](assets/images/mr.brown.jpg)

# Demo
View this jekyll theme in action [here](http://artemsheludko.pw/mr-brown/)

Integrations
  - [Google Fonts](https://fonts.google.com/)
  - [Disqus](https://disqus.com/)
  - [txtpen](https://txtpen.com/)
  - [Font Awesome](http://fontawesome.io/)
  - Social media links

# How to Use

  For those unfamiliar with how Jekyll works, check out [jekyllrb.com](https://jekyllrb.com/) for all the details,
  or read up on just the basics of [front matter](https://jekyllrb.com/docs/frontmatter/), [writing posts](https://jekyllrb.com/docs/posts/),
  and [creating pages](https://jekyllrb.com/docs/pages/).

## License

MIT License
